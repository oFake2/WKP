#include "pch.h"
#define DRIVER_TAG 'lpms'



UNICODE_STRING g_RegPath;

extern "C"
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
	UNREFERENCED_PARAMETER(RegistryPath);

	KdPrint(("DriverEntry Called: Registry Path: %wZ", RegistryPath));

	g_RegPath.Length = RegistryPath->Length;
	g_RegPath.MaximumLength = RegistryPath->Length;
	g_RegPath.Buffer = (WCHAR*)ExAllocatePoolWithTag(PagedPool, g_RegPath.Length, DRIVER_TAG);
	if (g_RegPath.Buffer == nullptr) {
		KdPrint(("Out of mem!\n")); 
		return STATUS_NO_MEMORY;
	}
	memcpy(g_RegPath.Buffer, RegistryPath->Buffer, g_RegPath.Length);

	KdPrint(("Allocated Buffer! Registry path: %wZ", &g_RegPath));
	DriverObject->DriverUnload = SimpleUnload;
	//DriverObject->MajorFunction[IRP_MJ_CREATE] = SimpleCreate;
	return STATUS_SUCCESS;
}

void SimpleUnload(PDRIVER_OBJECT)
{
	ExFreePool(g_RegPath.Buffer);

}