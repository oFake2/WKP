#include <ntddk.h>

#define DRIVER_TAG 'kefo'
PRTL_OSVERSIONINFOW VersionBuffer;
POBJECT_ATTRIBUTES attr; 
PHANDLE KeyHandle;
PUNICODE_STRING dwMinorVersion;
PUNICODE_STRING dwMajorVersion;


void UnloadFunc(PDRIVER_OBJECT)
{
	ExFreePool(VersionBuffer);
	ExFreePool(attr);
}

extern "C"
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
	UNREFERENCED_PARAMETER(RegistryPath);
	KdPrint(("Called Driver Entry\n"));
	VersionBuffer = (PRTL_OSVERSIONINFOW)ExAllocatePoolWithTag(PagedPool, sizeof (RTL_OSVERSIONINFOW), DRIVER_TAG);
	if (VersionBuffer == nullptr) {
		KdPrint(("Out of mem!\n"));
		return STATUS_NO_MEMORY;
	}
	if (RtlGetVersion(VersionBuffer) != STATUS_SUCCESS) {
		KdPrint(("GetVersion Failed!\n"));
	}
	KdPrint(("dwMajorVersion: %u, dwMinorVersion: %u, dwBuildNumber: %u",
		VersionBuffer->dwMajorVersion, VersionBuffer->dwMinorVersion, VersionBuffer->dwBuildNumber));
	DriverObject->DriverUnload = UnloadFunc;
	attr = (POBJECT_ATTRIBUTES)ExAllocatePoolWithTag(PagedPool, sizeof(OBJECT_ATTRIBUTES), DRIVER_TAG);
	if (attr == nullptr) {
		KdPrint(("Out of mem!\n"));
		return STATUS_NO_MEMORY;
	}	
	InitializeObjectAttributes(attr, RegistryPath, OBJ_KERNEL_HANDLE, nullptr, nullptr);
	if (ZwOpenKey(KeyHandle, GENERIC_READ | GENERIC_WRITE, attr) != STATUS_SUCCESS)
	{
		KdPrint(("ZwOpenKey Failed!\n"));
		return STATUS_ABANDONED;
	}

	UNICODE_STRING dwBuildNumber = RTL_CONSTANT_STRING(L"dwBuildNumber");

	//RtlInitUnicodeString(dwMajorVersion, L"dwMajorVersion");
	//RtlInitUnicodeString(dwMinorVersion, L"dwMinorVersion");
	if (ZwSetValueKey(KeyHandle, &dwBuildNumber, NULL, REG_SZ, &(VersionBuffer->dwBuildNumber), sizeof(ULONG)) != STATUS_SUCCESS)
	{
		KdPrint(("ZwSetValueKey Failed!\n"));
	}
	


	return STATUS_UNSUCCESSFUL;
}
