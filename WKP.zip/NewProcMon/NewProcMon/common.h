#pragma once

enum class EventType {
	ProcessCreate,
	ThreadCreate,
	ProcessExit
};

struct EventHeader
{
	USHORT Size;
	LARGE_INTEGER time;
};

struct ProcessExitData : EventHeader
{
	LARGE_INTEGER Time;
	ULONG ProcessId;
	ULONG EXitCode;
};

struct ProcessCreateData : EventHeader {
	LARGE_INTEGER Time;
	ULONG ProcessId;
	ULONG ParentProcessId;
	ULONG CreatingProcessId;
	ULONG CommandLineLength;
	WCHAR CommandLine[1];

};

union EventData {
	ProcessCreateData ProcessCreate;
	ProcessExitData ProcessExit;
};