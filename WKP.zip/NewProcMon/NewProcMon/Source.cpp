#include "Header.h"



LIST_ENTRY DataHead;
Mutex Lock;
ULONG DataItemCount;


void AddItem2(DataItem* item) {
	{
		Locker locker(Lock);
		if (DataItemCount > 100)
			RemoveHead();
		InsertTailList(&DataHead, &item->Link);
		DataItemCount++;
	}
	//DbgPrint(...);

}

DataItem* RemoveHead() {
	Locker locker(Lock);
	PLIST_ENTRY entry = RemoveHeadList(&DataHead);
	return CONTAINING_RECORD(entry, DataItem, Link);
}

void SimpleUnload(PDRIVER_OBJECT DriverObject) {
	UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\??\\NewProcMon");
	IoDeleteSymbolicLink(&symLink);
	IoDeleteDevice(DriverObject->DeviceObject);
	PsSetCreateProcessNotifyRoutineEx(&ProcessNotifyRoutineCallback, TRUE);
	PsRemoveCreateThreadNotifyRoutine(&PcreateThreadNotifyRoutine);
}

extern "C" NTSTATUS DriverEntry(
	PDRIVER_OBJECT DriverObject,
	PUNICODE_STRING RegistryPath) {
	UNREFERENCED_PARAMETER(RegistryPath);

	InitializeListHead(&DataHead);
	KeInitializeMutex((PRKMUTEX)&Lock, 0);
	NTSTATUS status;

	do {

		UNICODE_STRING name = RTL_CONSTANT_STRING(L"\\Device\\NewProcMon");
		PDEVICE_OBJECT devObj;
		status = IoCreateDevice(DriverObject, 0, &name, FILE_DEVICE_UNKNOWN, 0, FALSE, &devObj);
		if (!NT_SUCCESS(status))
		{
			KdPrint(("Failed to create Device 0x%X\n", status));
			break;
		}
		devObj->Flags |= DO_DIRECT_IO;

		UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\??\\NewProcMon");
		status = IoCreateSymbolicLink(&symLink, &name);
		if (!NT_SUCCESS(status))
		{
			KdPrint(("Failed to create symlink 0x%X\n", status));
			IoDeleteDevice(devObj);
			break;
		}

		status = PsSetCreateProcessNotifyRoutineEx(&ProcessNotifyRoutineCallback, FALSE);
		if (!NT_SUCCESS(status))
		{
			KdPrint(("Failed to bind process notify routine\n"));
			break;
		}
		status = PsSetCreateThreadNotifyRoutine(&PcreateThreadNotifyRoutine);
		if (!NT_SUCCESS(status))
		{
			KdPrint(("Failed to bind process notify routine\n"));
			break;
		}
	} while (0);

	
	DriverObject->DriverUnload = SimpleUnload;
	//DriverObject->MajorFunction[IRP_MJ_CREATE] = SimpleCreate;

	return status;
}


void ProcessNotifyRoutineCallback(
	PEPROCESS Process,
	HANDLE ProcessId,
	PPS_CREATE_NOTIFY_INFO CreateInfo
)

{
	if (CreateInfo)
	{
		KdPrint(("Process Create pid: %d\n", ProcessId));
	}
	else
	{
		KdPrint(("Process exit pid: %d\n", ProcessId));

	}
	UNREFERENCED_PARAMETER(Process);
}

void PcreateThreadNotifyRoutine(
	HANDLE ProcessId,
	HANDLE ThreadId,
	BOOLEAN Create
)
{
	UNREFERENCED_PARAMETER(Create);
	KdPrint(("Thread Create Tid: %d, PID: %d\n", ThreadId, ProcessId));
}