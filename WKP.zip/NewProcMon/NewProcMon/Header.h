#pragma once
#include <ntddk.h>

void ProcessNotifyRoutineCallback(
	PEPROCESS Process,
	HANDLE ProcessId,
	PPS_CREATE_NOTIFY_INFO CreateInfo
);

void PcreateThreadNotifyRoutine(
	HANDLE ProcessId,
	HANDLE ThreadId,
	BOOLEAN Create
);

struct MutexLocker {
	MutexLocker(KMUTEX& m) : _m(m) {
		KeWaitForSingleObject(&m, Executive, KernelMode, FALSE, nullptr);
	}
	~MutexLocker() {
		KeReleaseMutex(&_m, FALSE);
	}

private:
	KMUTEX& _m;
};

template<typename TLock>
struct Locker {
	Locker(TLock& lock) : _lock(lock) {
		lock.Lock();
	}
	~Locker() {
		_lock.Unlock();
	}
private:
	TLock& _lock;
};
struct Mutex {
	void Init() {
		KeInitializeMutex(&_m, 0);
	}

	void Lock() {
		KeWaitForSingleObject(&_m, Executive, KernelMode, FALSE, nullptr);
	}
	void Unlock() {
		KeReleaseMutex(&_m, FALSE);
	}
private:
	KMUTEX _m;
};

struct DataItem {
	int X;
	LIST_ENTRY Link;
	UNICODE_STRING Y;
};

DataItem* RemoveHead();