// Boost.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <Windows.h>
#include <stdio.h>
#include <Psapi.h>
#include "..\StrongHandle\RevealCommon.h"

int Error(const char* msg) {
	printf("%s (%u)\n", msg, GetLastError());
	return 1;
}
bool ShowProcessModules(HANDLE hProcess) {
	HMODULE hModule[1024];
	DWORD needed;
	if (!EnumProcessModules(hProcess, hModule, sizeof(hModule), &needed))
		return false;

	WCHAR name[256];
	for (int i = 0; i < needed / sizeof(HMODULE); i++) {
		if (GetModuleBaseName(hProcess, hModule[i], name, _countof(name)))
			printf("0x%p: %ws\n", hModule[i], name);
	}
	return true;
}

int main(int argc, const char* argv[]) {
	if (argc < 2) {
		printf("Usage: HandleClient <pid>\n");
		return 0;
	}

	HANDLE hFile = CreateFile(L"\\\\.\\ProcReveal", GENERIC_WRITE,
		0, nullptr, OPEN_EXISTING, 0, nullptr);
	if (hFile == INVALID_HANDLE_VALUE)
		return Error("Failed to open device");

	ProcessData data;
	data.pid = atoi(argv[1]);
	HANDLE hProcess;
	DWORD bytes;
	DeviceIoControl(hFile, IOCTL_OPEN_PROCESS, &data, sizeof(data),
		&hProcess, sizeof(hProcess), &bytes, nullptr);
	CloseHandle(hFile);
	if (hProcess) {
		ShowProcessModules(hProcess);
		CloseHandle(hProcess);
	}
	else
	{
		printf("Failed to open process handle.\n");
	}


	CloseHandle(hFile);
}
