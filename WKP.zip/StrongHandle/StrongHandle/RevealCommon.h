#pragma once
#define IOCTL_OPEN_PROCESS CTL_CODE(FILE_DEVICE_UNKNOWN , 1, METHOD_BUFFERED, FILE_ANY_ACCESS)
struct ProcessData
{
	ULONG pid;

};