#include <ntifs.h>

#include "RevealCommon.h"

void RevealUnload(PDRIVER_OBJECT);
NTSTATUS RevealCreateClose(PDEVICE_OBJECT, PIRP Irp);
NTSTATUS RevealDeviceControl(PDEVICE_OBJECT, PIRP Irp);
NTSTATUS CompleteIRP(PIRP irp, NTSTATUS status, ULONG info);

extern "C"
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING)
{
	DriverObject->DriverUnload = RevealUnload;

	DriverObject->MajorFunction[IRP_MJ_CREATE] = RevealCreateClose;
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = RevealCreateClose;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = RevealDeviceControl;

	UNICODE_STRING name = RTL_CONSTANT_STRING(L"\\Device\\ProcReveal");	
	PDEVICE_OBJECT devObj;
	auto status = IoCreateDevice(DriverObject, 0, &name, FILE_DEVICE_UNKNOWN, 0, FALSE, &devObj);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("Failed to create Device 0x%X\n", status));
		return status;
	}

	UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\??\\ProcReveal");
	status = IoCreateSymbolicLink(&symLink, &name);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("Failed to create symlink 0x%X\n", status));
		IoDeleteDevice(devObj);
		return status;
	}
	return STATUS_SUCCESS;

}
void RevealUnload(PDRIVER_OBJECT DriverObject)
{
	UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\??\\ProcReveal");
	IoDeleteSymbolicLink(&symLink);
	IoDeleteDevice(DriverObject->DeviceObject);
}
NTSTATUS CompleteIRP(PIRP irp, NTSTATUS status, ULONG info)

{
	irp->IoStatus.Status = status;
	irp->IoStatus.Information = info;
	IoCompleteRequest(irp, 0);
	return status;
}

NTSTATUS RevealCreateClose(PDEVICE_OBJECT, PIRP Irp)
{
	return CompleteIRP(Irp, STATUS_SUCCESS, 0);
}



NTSTATUS RevealDeviceControl(PDEVICE_OBJECT DriverObject, PIRP Irp)
{
	UNREFERENCED_PARAMETER(DriverObject);

	auto irpSp = IoGetCurrentIrpStackLocation(Irp);
	auto& dic = irpSp->Parameters.DeviceIoControl;
	auto status = STATUS_INVALID_DEVICE_REQUEST;
	switch (dic.IoControlCode)
	{
	case IOCTL_OPEN_PROCESS:
		{
		auto inputBuffer = Irp->AssociatedIrp.SystemBuffer;
		if (dic.OutputBufferLength < sizeof(HANDLE) || dic.InputBufferLength < sizeof(ProcessData))
		{
			status = STATUS_BUFFER_TOO_SMALL;
			break;
		}
		auto data = (ProcessData*)inputBuffer;
		if (data == nullptr || data->pid % 4 != 0)
		{
			status = STATUS_INVALID_PARAMETER;
			break;
		}
		HANDLE h;
		OBJECT_ATTRIBUTES oa = { 0 };
		CLIENT_ID id = { 0 };
		id.UniqueProcess =(HANDLE)data->pid;
		id.UniqueThread = (HANDLE)0;
		InitializeObjectAttributes(&oa, NULL, 0, 0, NULL);
		status = ZwOpenProcess(&h, PROCESS_ALL_ACCESS, &oa, &id);
		if (status != STATUS_SUCCESS)
		{
			KdPrint(("Failed to open process kernel\n"));
			break;
		}
		*(HANDLE*)Irp->AssociatedIrp.SystemBuffer = h;
		}
		CompleteIRP(Irp, status, sizeof(HANDLE));
	}
	return status;
}
